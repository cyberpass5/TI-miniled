/*
 * led_driver.h
 *
 * Copyright (C) 2023 Texas Instruments Incorporated - http://www.ti.com/ 
 * ALL RIGHTS RESERVED 
 *
 */
 
#ifndef LED_DRIVER_H_
#define LED_DRIVER_H_

#define FALSE 0
#define TRUE  1

#include "LP5891.h"

#endif /* LED_DRIVER_H_ */
